.. include:: ../README.rst

Contents
--------

.. toctree::
    :maxdepth: 2

    core
    pgn
    polyglot
    gaviota
    syzygy
    uci
    svg
    variant
    changelog

Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`
